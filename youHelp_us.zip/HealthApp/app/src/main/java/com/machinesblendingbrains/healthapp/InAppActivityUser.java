package com.machinesblendingbrains.healthapp;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.sql.Date;

public class InAppActivityUser extends AppCompatActivity {

    private BottomNavigationView navBar;
    private CalendarView calendar;
    private EditText setDate;
    private String date;
    private TextView tUserName;



    public InAppActivityUser() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app_user);
        navBar=(BottomNavigationView)findViewById(R.id.navBar);
        calendar=(CalendarView)findViewById(R.id.calendarUser);
        setDate=(EditText)findViewById(R.id.tDateUser);
        tUserName = (TextView)findViewById(R.id.tUserName);
        LoginActivity login = new LoginActivity();
        tUserName.setText(login.getName());
        tUserName.bringPointIntoView(6);
        //date=New Date();
        setDate.setText(date);

        //region Change tabs
        navBar.setSelectedItemId(R.id.nav_user);
        navBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_user:
                        Toast.makeText(InAppActivityUser.this, "You are already in profile tab", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_home:
                        openHomeActivity();
                        break;
                    case R.id.nav_map:
                        openMapActivity();
                        break;
                }
                return true;
            }

            private void openMapActivity() {
                Intent intent = new Intent(InAppActivityUser.this, InAppActivityMap.class);
                startActivity(intent);
            }
            private void openHomeActivity() {
                Intent intent = new Intent(InAppActivityUser.this, InAppActivity.class);
                startActivity(intent);
            }
        });
        //endregion
    }
}
