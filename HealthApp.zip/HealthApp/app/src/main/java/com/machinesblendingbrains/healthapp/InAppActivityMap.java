package com.machinesblendingbrains.healthapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

public class InAppActivityMap extends AppCompatActivity {

    private BottomNavigationView navBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app_map);
        navBar=(BottomNavigationView)findViewById(R.id.navBar);

        //region Change tabs
        navBar.setSelectedItemId(R.id.nav_map);
        navBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_map:
                        Toast.makeText(InAppActivityMap.this, "You are already in map view", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_home:
                        openHomeActivity();
                        break;
                    case R.id.nav_user:
                        openUserActivity();
                        break;
                }
                return true;
            }

            private void openUserActivity() {
                Intent intent = new Intent(InAppActivityMap.this, InAppActivityUser.class);
                startActivity(intent);
            }
            private void openHomeActivity() {
                Intent intent = new Intent(InAppActivityMap.this, InAppActivity.class);
                startActivity(intent);
            }
        });
        //endregion
    }
}
