package com.machinesblendingbrains.healthapp;

import android.Manifest;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.VibrationEffect;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.Header;

public class InAppActivity extends AppCompatActivity {

    private SensorManager sensorManager;
    private Sensor accelerometerSensor;
    private SensorEventListener accelerometerEventListener;
    private Button btnAlert;
    private Button home;
    private Button user;
    private Button map;

    private BottomNavigationView navBar;
    private int counter; //for countdown timer
    private long lastUpdate = 0;
    private float x, y, z;
    private CountDownTimer timer;
    private EditText tNum;
    private Double currentG;
    private String idPacient;
    private String raspunsId;
    private String raspunsIdUtilizatorPacient;
    private String raspunsLatitudine;
    private String raspunsLongitudine;
    private String raspunsMotiv;
    private double longitude;
    private double latitude;
    static final int REQUEST_LOCATION = 1;
    LocationManager locationManager;

    private Vibrator vibration() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(VibrationEffect.createOneShot(1000, 255));
        return vibrator;
    }

    private String url = "https://direwolf.ro/danielcata/public/v1/utilizatori/login/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_app);
        navBar = (BottomNavigationView) findViewById(R.id.navBar);
        LoginActivity login = new LoginActivity();
        Intent intent = getIntent();
        idPacient = intent.getStringExtra("idPacient");
        Toast toast = Toast.makeText(InAppActivity.this, idPacient, Toast.LENGTH_SHORT);
        toast.show();


        //region New Location Manager
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        getLocation();
        //endregion

        //region Change tabs
        navBar.setSelectedItemId(R.id.nav_home);
        navBar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_home:
                        Toast.makeText(InAppActivity.this, "You are already home", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_map:
                        openMapActivity();
                        break;
                    case R.id.nav_user:
                        openUserActivity();
                        break;
                }
                return true;
            }

            private void openUserActivity() {
                Intent intent = new Intent(InAppActivity.this, InAppActivityUser.class);
                startActivity(intent);
            }

            private void openMapActivity() {
                Intent intent = new Intent(InAppActivity.this, InAppActivityMap.class);
                startActivity(intent);
            }
        });
        //endregion

        //region Acceleormeter code hidden here
        sensorManager = (SensorManager)

                getSystemService(Context.SENSOR_SERVICE);

        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        tNum = (EditText) findViewById(R.id.tNum);
        accelerometerEventListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {

                if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    x = event.values[0];
                    y = event.values[1];
                    z = event.values[2];
                    Double currentF = (Math.sqrt(x * x + y * y + z * z));
                    if (currentF < 3) {
                        Toast toast = Toast.makeText(InAppActivity.this, "Force is below 3*(m/s^2) : " + currentF, Toast.LENGTH_SHORT);
                        toast.show();
                        postFunction();
                    }
                    tNum.setText("Number of (m/s^2)" + currentF);
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
            }
        }

        ;
        sensorManager.registerListener(accelerometerEventListener,
                accelerometerSensor, SensorManager.SENSOR_DELAY_NORMAL);
        //endregion


        //region Alert button code hidden here
        btnAlert = (Button)

                findViewById(R.id.btnAlert);
        btnAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //region Timer
                timer = new CountDownTimer(10000, 1000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        counter++;
                    }

                    @Override
                    public void onFinish() {
                        vibration();
                        vibration().cancel();

                    }
                }.start();
                //endregion

                //region Dialog
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case DialogInterface.BUTTON_POSITIVE:
                                Toast toast = Toast.makeText(InAppActivity.this, "We're relieved to hear that!", Toast.LENGTH_SHORT);
                                toast.show();
                                dialog.dismiss();
                                break;
                            case DialogInterface.BUTTON_NEGATIVE:
                                postFunction();
                                dialog.dismiss();
                                break;
                            default:
                                if (counter == 10000) {
                                    //sendRequestAndGetResponsePost();
                                    dialog.cancel();
                                    break;
                                }
                        }
                    }
                };
                //endregion

                //region Dialog properties
                AlertDialog.Builder builder = new AlertDialog.Builder(InAppActivity.this);
                builder.setCancelable(false);
                builder.setMessage("Did you send the alert accidentally?")
                        .setPositiveButton("Yes, I'm fine.", dialogClickListener)
                        .setNegativeButton("No, send help! (app will ask for help in 10 secs)", dialogClickListener).show();
                //endregion

            }


        });
        //endregion
    }

    void getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        } else {
            Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (location != null) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case REQUEST_LOCATION:
                getLocation();
                break;
        }
    }

    public void postFunction() {
        RequestParams rp = new RequestParams();
        rp.add("id_utilizator_pacient", idPacient);
        rp.add("latitudine", "44.4733573");
        rp.add("longitudine", "26.0656154");
        rp.add("motiv", "A cazut brusc.");

        HttpUtils.post("alerta/create", rp, new JsonHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // If the response is JSONObject instead of expected JSONArray
                Log.d("asd", "---------------- this is response : " + response);
                try {
                    JSONObject serverResp = new JSONObject(response.toString());
                    raspunsId = serverResp.get("id").toString();
                    raspunsIdUtilizatorPacient = serverResp.get("id_utilizator_pacient").toString();
                    raspunsLatitudine = serverResp.get("latitudine").toString();
                    raspunsLongitudine = serverResp.get("longitudine").toString();
                    raspunsMotiv = serverResp.get("motiv").toString();
                    Toast toast = Toast.makeText(InAppActivity.this, "Sent alert:\n Id:" + raspunsId + "\n Latitudine:"
                            + raspunsLatitudine + "\n Longitudine:" + raspunsLongitudine + "\n Motive:" + raspunsMotiv, Toast.LENGTH_SHORT);
                    toast.show();

                } catch (JSONException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray timeline) {
                // Pull out the first event on the public timeline
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable thr, JSONObject response) {
                // Pull out the first event on the public timeline
                /*Toast toast = Toast.makeText(InAppActivity.this, "Couldn't connect to server.", Toast.LENGTH_SHORT);
                toast.show();*/
                Toast toast = Toast.makeText(InAppActivity.this, response.toString(), Toast.LENGTH_SHORT);
                toast.show();
            }
        });
    }
}


