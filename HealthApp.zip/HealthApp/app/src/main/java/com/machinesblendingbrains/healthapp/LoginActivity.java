package com.machinesblendingbrains.healthapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.preference.PreferenceActivity;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.*;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import cz.msebera.android.httpclient.Header;

public class LoginActivity extends AppCompatActivity {

    private Button btnLogin;
    private EditText tPassword;
    private EditText tUsername;
    private String username;
    private String password;
    private String sUsername;
    private String sPassword;
    private String url;
    private String id;
    private String name;

    public String getName() {
        return name;
    }
    public String getId(){
        return id;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnLogin = (Button) findViewById(R.id.btnSignIn);
        tUsername = (EditText) findViewById(R.id.tUsername);
        tPassword = (EditText) findViewById(R.id.tPassword);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.getId();

            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password = tPassword.getText().toString();
                username = tUsername.getText().toString();
                RequestParams rp = new RequestParams();
                rp.add("name", username);
                rp.add("password", password);
                HttpUtils.post("utilizatori/login", rp, new JsonHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        // If the response is JSONObject instead of expected JSONArray
                        Log.d("asd", "---------------- this is response : " + response);
                        try {
                            JSONObject serverResp = new JSONObject(response.toString());
                            id = serverResp.get("id_utilizator").toString();
                            name = serverResp.get("name").toString();
                            openInAppActivity();
                            Toast toast = Toast.makeText(LoginActivity.this, "Welcome, " + name, Toast.LENGTH_SHORT);
                            toast.show();
                            Intent intent = new Intent(LoginActivity.this, InAppActivity.class );
                            intent.putExtra("idPacient", id);
                            startActivity(intent);


                        } catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONArray timeline) {
                        // Pull out the first event on the public timeline
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable thr, JSONObject response) {
                        // Pull out the first event on the public timeline
                        Toast toast = Toast.makeText(LoginActivity.this, "Input was incorect. Please try again.", Toast.LENGTH_SHORT);
                        toast.show();
                    }
                });
            }
        });
    }

    private void openInAppActivity() {
        Intent intent = new Intent(this, InAppActivity.class);
        startActivity(intent);
    }
}